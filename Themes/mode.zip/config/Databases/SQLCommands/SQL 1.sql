CREATE TABLE Product (
    ID int NOT NULL GENERATED ALWAYS AS IDENTITY,
    "Name" varchar(255) NOT NULL,    
    Price Decimal Not NULL,
    CHECK (Price>=1),
    PRIMARY KEY (ID)
);