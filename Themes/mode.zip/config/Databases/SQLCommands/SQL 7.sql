CREATE TABLE "USER"
(ID INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY(Start with 1, Increment by 1), 
"NAME" varchar(255) NOT NULL,
EMAIL varchar(255) NOT NULL CHECK(EMAIL LIKE ( '^[a-zA-Z0-9][a-zA-Z0-9._-]*[a-zA-Z0-9_\-]@[a-zA-Z0-9][a-zA-Z0-9._-]*[a-zA-Z0-9]\.[a-zA-Z]+$')),
PASSWORD varchar(255) NOT NULL,
PHONE varchar(255) NOT NULL,
GENDER varchar(255) NOT NULL,
DOB varchar(255) NOT NULL,
PRIMARY KEY (ID));